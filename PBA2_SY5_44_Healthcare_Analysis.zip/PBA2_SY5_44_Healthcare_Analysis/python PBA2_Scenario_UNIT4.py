import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# 1. Load and inspect dataset
if not os.path.exists("patient_dataset.csv"):
    data = {
        "age": [25, 30, 35, 40, 45, 50, 55, 60, 65, 70],
        "blood_pressure": [110, 120, 125, 130, None, 140, 145, 150, 155, 160],
        "cholesterol": [170, 180, 190, 200, 210, 220, 230, 240, 250, 260]
    }
    pd.DataFrame(data).to_csv("patient_dataset.csv", index=False)

df = pd.read_csv("patient_dataset.csv")

print("First five records:")
print(df.head())

print("Dataset information:")
df.info()

print("Dataset shape:")
print(df.shape)


# 2. Handle missing values and duplicates
print("Missing values:")
print(df.isnull().sum())

print("Duplicate records:")
print(df.duplicated().sum())

df.fillna(df.mean(numeric_only=True), inplace=True)
df.drop_duplicates(inplace=True)

print("Cleaned dataset:")
print(df.head())


# 3. Descriptive statistics
print("Descriptive statistics:")
print(df[["age", "blood_pressure", "cholesterol"]].describe())


# 4. Relationship between age and cholesterol
print("Correlation:")
print(df["age"].corr(df["cholesterol"]))


# 5. Histogram
df[["age", "blood_pressure", "cholesterol"]].hist()
plt.show()

# Scatter plot
plt.scatter(df["age"], df["cholesterol"])
plt.xlabel("Age")
plt.ylabel("Cholesterol")
plt.title("Age vs Cholesterol")
plt.show()

# Box plot
sns.boxplot(data=df[["age", "blood_pressure", "cholesterol"]])
plt.title("Patient Data Box Plot")
plt.show()

# Save cleaned dataset
df.to_csv("cleaned_patient_dataset.csv", index=False)

print("Cleaned dataset saved successfully.")
