
import csv

with open("students.csv", "r", newline="") as file:
    reader = csv.DictReader(file)

    with open("output.csv", "w", newline="") as outfile:
        writer = csv.DictWriter(
            outfile,
            fieldnames=reader.fieldnames
        )

        writer.writeheader()

        print("Students who scored more than 75:")

        for student in reader:
            if int(student["marks"]) > 75:
                print(student)
                writer.writerow(student)

print("Output file created")
